
public interface Command {

	
	public void execute();
	
	public void execute(String s);
	
	
	public String getParam();
	
	public String getName();
}
